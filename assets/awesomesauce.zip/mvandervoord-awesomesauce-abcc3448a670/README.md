# Dr Surly's School For Mad Scientists: #

## Unit Testing & Other Embedded Software Catalysts ##

This is a collection of project starters for those taking our class. Clone it and use it as instructed in class.

### What is this repository for? ###

* Following in-class examples
* Inspiration for you own projects

### Problems? ###

* Please let your [friendly instructors](mailto:tdd@throwtheswitch.org) know if you have any issues. We'll do our best to resolve them.
* You may find useful resources at [ThrowTheSwitch](http://throwtheswitch.org)
* You may also share your concerns on our [Forums](http://throwtheswitch.org/forums)
