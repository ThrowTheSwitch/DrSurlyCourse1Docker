# Dr Surly's School For Mad Scientists: #

Hi.

You've found the Finished Folder, where all the completed projects live.
Feel free to use these as reference when you get stuck. We recommend
working through the problems without peeking here, until you run into
trouble. Consider this folder your "Get Out Of Trouble" card.

Good luck!

Sincerely, The Mad Scientists
