#ifndef FIB_H
#define FIB_H

int Fibonacci_GetElement(int num);
int Fibonacci_IsInSequence(int num);

#endif //FIB_H
